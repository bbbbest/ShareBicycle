import * as types from './types';
import me from '../api/me';

export const actions = {
  [types.DO_LOGIN] ({commit, dispatch}, {username, password}) {
    return new Promise((resolve, reject) => {
      me.check({username: username, password: password})
        .then((response) => {
          let data = response.data;
          if (data.status === 200) {
            // 设置登陆标志
            commit(types.SET_IS_LOGIN, true);
            // 设置个人信息
            commit(types.SET_ADMIN_INFO, data.data);
            // 抓取并初始化权限表
            dispatch(types.FETCH_ALL_PRIVILEGES);
            // 成功-回调
            resolve();
          } else {
            // 失败-回调，指成功连接但是后端确认失败
            reject();
          }
        })
        .catch((error) => {
          // 失败-回调，指未成功连接
          console.log(error);
          reject();
        });
    });
  },
  [types.DO_LOGOUT] ({commit}) {
    commit(types.SET_IS_LOGIN, false);
  }
};

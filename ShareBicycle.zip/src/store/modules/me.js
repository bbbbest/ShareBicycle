import * as types from '../types';
import me from '../../api/me';

const state = {
  me: {
    adminId: '',
    username: '',
    name: '',
    privilegeId: -1,
    privilege: {
      // requireUser: false,
      // requireActivity: false,
      // requireAdmin: false,
      // requireAdvice: false,
      // requireBicycle: false,
      // requireCyclingrecord: false,
      // requireDealrecord: false,
      // updateUser: false,
      // updayeActivity: false,
      // updateAdmin: false,
      // updateAdvice: false,
      // updateBicycle: false,
      // updateCyclingrecord: false,
      // updateDealrecord: false
    }
  }
};
const getters = {
  adminId: (state) => state.adminId,
  username: (state) => state.username,
  name: (state) => state.name,
  adminInfo: (state) => {
    return {
      adminId: state.me.adminId,
      username: state.me.username,
      name: state.me.name,
      privilegeId: state.me.privilegeId
    };
  },
  privilege: (state) => state.privilege,
  requireUser: (state) => state.me.privilege.requireUser,
  updateUser: (state) => state.me.privilege.updateUser,
  requireActivity: (state) => state.me.privilege.requireActivity,
  updayeActivity: (state) => state.me.privilege.updayeActivity,
  requireAdmin: (state) => state.me.privilege.requireAdmin,
  updateAdmin: (state) => state.me.privilege.updateAdmin,
  requireAdvice: (state) => state.me.privilege.requireAdvice,
  updateAdvice: (state) => state.me.privilege.updateAdvice,
  requireBicycle: (state) => state.me.privilege.requireBicycle,
  updateBicycle: (state) => state.me.privilege.updateBicycle,
  requireCyclingrecord: (state) => state.me.privilege.requireCyclingrecord,
  updateCyclingrecord: (state) => state.me.privilege.updateCyclingrecord,
  requireDealrecord: (state) => state.me.privilege.requireDealrecord,
  updateDealrecord: (state) => state.me.privilege.updateDealrecord
};
const actions = {
  [types.RESET_PASSWORD] ({commit}, {old, n}) {
    return new Promise((resolve, reject) => {
      me.resetPWD({old: old, n: n})
        .then((response) => {
          if (response.data.status === 200) {
            resolve();
          } else {
            reject();
          }
        })
        .catch((error) => {
          console.log(error);
          reject();
        });
    });
  }
};
const mutations = {
  [types.SET_ADMIN_INFO] (state, {adminId, username, name, privilegeId}) {
    state.me.adminId = adminId;
    state.me.username = username;
    state.me.name = name;
    state.me.privilegeId = privilegeId;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};

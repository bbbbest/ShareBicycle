import me from '../api/me';
import privilege from '../api/privilege';
export default {
  me: me,
  privilege: privilege
};

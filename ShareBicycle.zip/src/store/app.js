export default {
  name: '郑在行后台管理',
  version: '1.0.0'
};

import * as types from './types';

export const mutations = {
  [types.SET_IS_LOGIN] (state, value) {
    state.islogin = value;
  },
  [types.SET_TOKEN] (state, token) {
    state.token = token;
  },
  [types.DESTROY_TOKEN] (state) {
    state.token = '';
  }
};

export const getters = {
  islogin: (state) => state.islogin,
  token: (state) => state.token
};

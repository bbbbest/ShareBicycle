<template>
  <div class="container">
    <el-row :gutter="10" style="margin-bottom: 10px">
      <el-col :span="3">
        <el-select v-model="option" placeholder="请选择">
          <el-option
            v-for="option in options"
            :key="option.value"
            :label="'按 ' + option.label"
            :value="option.value">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="8">
        <el-input placeholder="搜索">
          <el-button slot="append" icon="search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="13" style="text-align: right">
        <span><router-link type="text" to="/bikes/add"
                           style="text-decoration: none;margin-right: 10px">添加新车</router-link></span>
        <el-button type="primary" :loading="loading" @click="reload">{{loading? '加载中':'刷新'}}</el-button>
      </el-col>
    </el-row>
    <el-table
      :data="bikes"
      border
      stripe
      max-height="500">
      <el-table-column
        prop="id"
        label="编号"
        align="center"
        width="80">
      </el-table-column>
      <el-table-column
        prop="masterId"
        label="贡献者"
        width="160"
        align="center">
        <template scope="scope">
          <el-popover trigger="click" placement="top">
            <p>姓名: {{ clickedUser.name }}</p>
            <p>电话: {{ clickedUser.phone }}</p>
            <div slot="reference">
              <span @click="clickName(scope.row.masterId)">{{ scope.row.masterId | getNameById }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        prop="time"
        sortable
        label="贡献时间"
        width="160"
        align="center">
      </el-table-column>
      <el-table-column
        prop="lockId"
        label="锁编号"
        align="center">
      </el-table-column>
      <el-table-column
        prop="location"
        label="现地址"
        align="center">
        <template scope="scope">
          (<span>{{scope.row.location.x}}</span>,<span>{{scope.row.location.y}}</span>)
        </template>
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        align="center"
        width="80">
      </el-table-column>
      <el-table-column
        prop="energy"
        label="电池电量"
        align="center"
        width="120">
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        width="130">
        <template scope="scope">
          <el-button size="small" type="text" @click="edit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row style="margin-top: 10px">
      <el-col :span="6">&nbsp;</el-col>
      <el-col :span="12" style="text-align: center">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pagination.currentPage"
          :page-sizes="pagination.pageSizes"
          :page-size="pagination.pageSize"
          layout="sizes, prev, pager, next, jumper"
          :total="pagination.total">
        </el-pagination>
      </el-col>
      <el-col :span="6">&nbsp;</el-col>
    </el-row>
    <el-dialog
      title="车辆信息"
      :visible.sync="dialogVisible"
      :before-close="handleDialogClose">
      <div style="width: 90%">
        <el-form
          ref="bikeInfo"
          :model="bikeInfo"
          label-width="80px">
          <el-form-item label="编号" prop="id">
            <el-input v-model="bikeInfo.id"></el-input>
          </el-form-item>
          <el-form-item label="照片" prop="photo">
            <el-row>
              <el-col :span="10">
                <el-card :body-style="{ padding: '0px'}">
                  <img style="width:100%; display: block;" alt="自行车照片" :src='getPhoto(bikeInfo.id)'>
                </el-card>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item label="锁编号" prop="lockId">
            <el-input v-model="bikeInfo.lockId"></el-input>
          </el-form-item>
          <el-form-item label="状态" prop="status">
            <el-input v-model="bikeInfo.status"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" :loading="bikeInfo.loading" class="submit" @click="submit">确认修改</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>
<script type="text/ecmascript-6">
  import {mapGetters} from 'vuex';
//  import * as types from '../store/types';

  export default {
    name: 'all-bikes',
    data () {
      // 数据
      return {
        dialogVisible: false,
        loading: false,
        option: 1,
        options: [
          {
            label: '编号',
            value: 1
          },
          {
            label: '锁编号',
            value: 2
          }
        ],
        clickedUser: {
          name: '杨洁',
          phone: 0
        },
        bikeInfo: {
          id: '1',
          photo: '',
          lockId: '123456',
          status: '1',
          loading: false
        },
        bikes: [
          {
            id: '1',
            masterId: 1,
            time: '2017-08-10',
            photo: '',
            lockId: '123456',
            location: {
              x: '123.12356',
              y: '456.5625'
            },
            status: '1',
            energy: '100'
          },
          {
            id: '2',
            masterId: 2,
            time: '2017-08-10',
            photo: '',
            lockId: '223456',
            location: {
              x: '123.12356',
              y: '456.5625'
            },
            status: '1',
            energy: '100'
          },
          {
            id: '3',
            masterId: 3,
            time: '2017-08-10',
            photo: '',
            lockId: '223456',
            location: {
              x: '123.12356',
              y: '456.5625'
            },
            status: '1',
            energy: '100'
          }
        ]
      };
    },
    methods: {
      // 方法
      openDialog () {
        this.dialogVisible = true;
      },
      closeDialog () {
        this.dialogVisible = false;
      },
      handleDialogClose () {
        this.closeDialog();
        this.$message({
          message: '取消操作',
          type: 'info',
          duration: 1000
        });
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`);
      },
      reload () {
        if (!this.loading) {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
            this.$message.success('更新成功');
          }, 1000);
        }
      },
      clickName (id) {
        console.log(id);
        this.clickedUser.name = '用户 ' + id;
        this.clickedUser.phone = id + id << 2 + id << 4 + id << 6;
      },
      edit (row) {
        this.bikeInfo.id = row.id;
        this.bikeInfo.photo = row.photo;
        this.bikeInfo.lockId = row.lockId;
        this.bikeInfo.status = row.status;
        this.openDialog();
      },
      del (row) {
        this.$confirm('您即将删除一辆自行车, 仍要继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      },
      getPhoto (id) {
        return 'https://upload.wikimedia.org/wikipedia/commons/4/41/Left_side_of_Flying_Pigeon.jpg';
      },
      submit () {
        this.bikeInfo.loading = true;
        this.$ajax.get('http://127.0.0.1:80')
          .then(response => {
            this.bikeInfo.loading = false;
            this.closeDialog();
            this.$message('更新成功');
          })
          .catch(p1 => {
            this.bikeInfo.loading = false;
            this.$message({
              type: 'error',
              message: '更新失败'
            });
          });
      }
    },
    computed: {
      ...mapGetters({
        pagination: 'bikesPagination'
      })
    },
    filters: {
      getNameById (id) {
        return '用户 ' + id;
      }
    }
  };
</script>
<style scoped>
  @import "../assets/global/css/global.css";
</style>

<template>
  <div class="container">
    <el-row :gutter="10" style="margin-bottom: 10px">
      <el-col :span="3">
        <el-select v-model="option" placeholder="请选择">
          <el-option
            v-for="option in options"
            :key="option.value"
            :label="'按 ' + option.label"
            :value="option.value">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="8">
        <el-input placeholder="搜索">
          <el-button slot="append" icon="search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="13" style="text-align: right">
        <el-button type="primary" :loading="loading" @click="reload">{{loading? '加载中':'刷新'}}</el-button>
      </el-col>
    </el-row>
    <el-table
      :data="tableData"
      border
      stripe
      max-height="550">
      <el-table-column
        prop="adminId"
        label="工号"
        align="center">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名"
        align="center"
        width="100">
      </el-table-column>
      <el-table-column
        prop="auth"
        label="当前权限"
        header-align="center"
        width="800">
        <template scope="scope">
          <div class="checkbox-group" v-for="i in Object.keys(scope.row.auth)">
            <span>{{i | aliasFilter}}</span>
            <el-checkbox :key="i + '-query'" disabled :checked="scope.row.auth[i].query">读</el-checkbox>
            <el-checkbox :key="i + '-update'" disabled :checked="scope.row.auth[i].update">写</el-checkbox>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        width="130">
        <template scope="scope">
          <el-button size="small" type="text" @click="edit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row style="margin-top: 10px">
      <el-col :span="8">&nbsp;</el-col>
      <el-col :span="8" style="text-align: center">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pagination.currentPage"
          :page-sizes="pagination.pageSizes"
          :page-size="pagination.pageSize"
          layout="sizes, prev, pager, next, jumper"
          :total="pagination.total">
        </el-pagination>
      </el-col>
      <el-col :span="8">&nbsp;</el-col>
    </el-row>
    <el-dialog
      :modal-append-to-body="false"
      title="提示"
      :visible.sync="dialogVisible"
      size="large"
      :before-close="handleClose">
      <el-form :inline="true" ref="form" :model="form" label-width="80px">
        <el-form-item label="工号">
          <el-input v-model="form.adminId" size="small" disabled></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input v-model="form.name" size="small" disabled></el-input>
        </el-form-item>
        <el-form-item label="权限">
          <el-select v-model="form.freshRoleId" size="small" :placeholder="form.roleId">
            <el-option
              v-for="privilege in allPrivileges"
              :key="privilege.id"
              :label="privilege.id"
              :value="privilege.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="权限表">
          <privileges :tableHeight="200"></privileges>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="text" @click="handleClose">取&nbsp;消</el-button>
        <el-button type="primary" @click="submit">提&nbsp;交</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script type="text/ecmascript-6">
  const map = {
    admin: '管理员',
    user: '用户',
    activity: '活动',
    advice: '反馈建议',
    bicycle: '自行车',
    cyclingrecord: '骑行记录',
    dealrecord: '消费记录'
  };

  import {mapGetters} from 'vuex';

  export default {
    name: 'modify-authority',
    components: {privileges: require('./Privileges')},
    props: {
      // 参数
    },
    data () {
      // 数据
      return {
        loading: false,
        option: 1,
        options: [
          {
            label: '工号',
            value: 1
          },
          {
            label: '姓名',
            value: 2
          }
        ],
        dialogVisible: false,
        admins: [
          {
            adminId: '1',
            name: 'Tom',
            roleId: '1',
            auth: {
              admin: {
                query: true,
                update: false
              },
              user: {
                query: true,
                update: true
              },
              activity: {
                query: true,
                update: false
              },
              advice: {
                query: true,
                update: false
              },
              bicycle: {
                query: true,
                update: false
              },
              cyclingrecord: {
                query: true,
                update: false
              },
              dealrecord: {
                query: true,
                update: false
              }
            }
          },
          {
            adminId: '2',
            name: 'Jane',
            roleId: '2',
            auth: {
              admin: {
                query: false,
                update: false
              },
              user: {
                query: true,
                update: false
              },
              activity: {
                query: true,
                update: false
              },
              advice: {
                query: true,
                update: false
              },
              bicycle: {
                query: true,
                update: false
              },
              cyclingrecord: {
                query: true,
                update: false
              },
              dealrecord: {
                query: true,
                update: false
              }
            }
          }
        ],
        pagination: {
          total: 100,
          pageSizes: [20, 30, 40],
          pageSize: 20,
          currentPage: 1
        },
        form: {
          adminId: '',
          name: '',
          roleId: '',
          freshRoleId: ''
        }
      };
    },
    mounted () {
    },
    methods: {
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`);
      },
      reload () {
        if (!this.loading) {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
          }, 3000);
        }
      },
      openDialog () {
        this.dialogVisible = true;
      },
      closeDialog () {
        this.dialogVisible = false;
      },
      // 方法
      edit (row) {
        this.form.adminId = row.adminId;
        this.form.name = row.name;
        this.form.role = row.roleId;
        this.openDialog();
      },
      del (row) {
        this.$confirm('您即将删除一名管理员, 仍要继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      },
      handleClose (event) {
        this.closeDialog();
        this.$message({
          type: 'info',
          message: '取消操作！',
          duration: 1000
        });
      },
      submit () {
        this.closeDialog();
        this.$message({
          type: 'success',
          message: '修改成功！',
          duration: 1000
        });
      }
    },
    computed: {
      // 计算属性
      tableData () {
        return this.admins;
      },
      ...mapGetters(['allPrivileges'])
    },
    filters: {
      aliasFilter: (val) => map[val]
    }
  };
</script>
<style scoped>
  @import '../assets/global/css/global.css';
  .checkbox-group {
    width: 160px;
    margin-left: 20px;
    line-height: 30px;
    display: inline-block;
  }

  .checkbox-group > span {
    display: inline-block;
    width: 4em;
    margin-right: 5px;
  }
</style>

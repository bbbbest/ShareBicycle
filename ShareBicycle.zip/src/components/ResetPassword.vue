<template>
  <div class='reset-password'>
    <el-form ref='form' :model='form' label-width='80px'>
      <el-form-item label='旧密码'>
        <el-input type='password' v-model='form.oldPassword'></el-input>
      </el-form-item>
      <el-form-item label='新密码'>
        <el-input type='password' v-model='form.newPassword'></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type='primary' @click='onSubmit'>提交修改</el-button>
      </el-form-item>
    </el-form>
    <label>{{form.oldPassword}}</label><br>
    <label>{{form.newPassword}}</label>
  </div>
</template>
<script type='text/ecmascript-6'>
  export default {
    name: 'reset-password',
    props: {
      // 参数
    },
    components: {
      // 组件
    },
    data () {
      // 数据
      return {
        msg: '',
        form: {
          oldPassword: '',
          newPassword: ''
        }
      };
    },
    methods: {
      // 方法
      onSubmit () {
        if (this.form.oldPassword !== this.form.newPassword) {
          this.$store.dispatch('RESET_PASSWORD', {old: this.form.oldPassword, n: this.form.newPassword})
            .then(() => {
              // 修改成功
              this.$message.success('Success');
            })
            .catch(() => {
              // 修改失败
              this.$message.error('Error');
            });
        } else {
          // 两次密码一样了
          this.$message.error('Error');
        }
      }
    },
    computed: {
      // 计算属性
    },
    filters: {
      // 过滤器
    },
    watch: {
      // 监听器
    }
  };
</script>
<style scoped>
  .reset-password {
    width: 50%;
    margin: 80px auto;
  }
</style>

<template>
  <div class="container">
    <el-row :gutter="10" style="margin-bottom: 10px">
      <el-col :span="3">
        <el-select v-model="option" placeholder="请选择">
          <el-option
            v-for="option in options"
            :key="option.value"
            :label="'按 ' + option.label"
            :value="option.value">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="8">
        <el-input placeholder="搜索">
          <el-button slot="append" icon="search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="13" style="text-align: right">
        <el-button type="primary" :loading="loading" @click="reload">{{loading? '加载中':'刷新'}}</el-button>
      </el-col>
    </el-row>
    <el-tabs>
      <el-tab-pane>
        <span slot="label"><i class="el-icon-date"></i> 所有反馈</span>
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label"><i class="el-icon-message"></i> 未回复<el-badge class="item" is-dot/></span>
      </el-tab-pane>
    </el-tabs>
    <el-table
      :data="advise"
      border
      stripe
      max-height="500"
      style="width: 100%">
      <el-table-column type="expand" width="30">
        <template scope="props">
          <div class="feedback-content">
            <div class="content">{{ props.row.content }}</div>
            <span class="createTime">{{ props.row.createTime }}</span>
          </div>
          <div v-if="props.row.status == 0" class="reply">
            <el-input type="textarea" autosize></el-input>
            <el-button class="submit" size="small">提交</el-button>
          </div>
          <div v-else class="reply-content">
            <div class="content">{{ props.row.replyContent }}</div>
            <span class="createTime">{{ props.row.replyTime }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="id"
        label="编号"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="creator"
        label="提出人"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="title"
        label="标题"
        align="center">
      </el-table-column>
      <el-table-column
        prop="createTime"
        label="创建时间"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        align="center"
        width="80">
      </el-table-column>
    </el-table>
    <el-row style="margin-top: 10px">
      <el-col :span="6">&nbsp;</el-col>
      <el-col :span="12" style="text-align: center">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pagination.currentPage"
          :page-sizes="pagination.pageSizes"
          :page-size="pagination.pageSize"
          layout="sizes, prev, pager, next, jumper"
          :total="pagination.total">
        </el-pagination>
      </el-col>
      <el-col :span="6">&nbsp;</el-col>
    </el-row>
  </div>
</template>
<script type="text/ecmascript-6">
  import {mapGetters} from 'vuex';

  export default {
    name: 'all-feedback',
    data () {
      // 数据
      return {
        dialogVisible: false,
        loading: false,
        option: 1,
        options: [
          {
            label: '编号',
            value: 1
          }
        ],
        advise: [
          {
            id: 1,
            creator: 1,
            title: '111',
            content: '你们服务为什么这么好啊？\n你们服务为什么这么好啊？\n你们服务为什么这么好啊？\n你们服务为什么这么好啊？\n你们服务为什么这么好啊？\n你们服务为什么这么好啊？\n',
            createTime: new Date().toLocaleDateString(),
            status: 1,
            replyContent: '因为我们很优秀啊\r\n因为我们很优秀啊\n因为我们很优秀啊\n因为我们很优秀啊\n',
            replyTime: new Date().toLocaleDateString()
          }
        ]
      };
    },
    methods: {
      // 刷新按钮
      reload () {
        if (!this.loading) {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
            this.$message.success('更新成功');
          }, 3000);
        }
      },
      // 对话框开关
      openDialog () {
        this.dialogVisible = true;
      },
      closeDialog () {
        this.dialogVisible = false;
      },
      // 对话框关闭处理
      handleDialogClose () {
        this.closeDialog();
        this.$message({
          message: '取消操作',
          type: 'info',
          duration: 1000
        });
      },
      edit (row) {
        this.openDialog();
      },
      del (row) {
        this.$confirm('您即将删除一条反馈, 仍要继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      },
      // 处理分页
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`);
      }
    },
    computed: {
      ...mapGetters({
        pagination: 'feedbackPagination'
      })
    }
  };
</script>
<style scoped>
  @import "../assets/global/css/global.css";

  .feedback-content, .reply, .reply-content {
    margin-top: 15px !important;
    line-height: 2;
    width: 100%;
  }

  .feedback-content:before {
    content: '反馈内容';
  }

  .reply-content:before {
    content: '回复内容';
  }

  .reply:before {
    content: '回复';
  }

  .feedback-content:before, .reply:before, .reply-content:before {
    margin-top: 10px;
    display: block;
    color: #8c939d;
    width: 120px;
    min-height: 40px;
    font-size: 1.2em;
  }

  .content {
    display: inline-block;
  }

  .createTime {
    display: inline-block;
    color: #8c939d;
    font-size: 12px;
    float: right;
    margin-right: 15px;
  }


</style>

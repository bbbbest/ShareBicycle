<template>
  <div class="index">
    <!--顶部导航-->
    <header class="header">
      <div class="brand"><span class="name">{{app.name}}</span><span class="version">V {{app.version}}</span></div>
      <div class="greeting">工号&nbsp;&nbsp;<router-link to="/me" style="text-decoration: none"><span class="user">{{adminId}}</span></router-link>
      </div>
      <div class="quick-message">
        <el-dropdown>
          <span class="el-dropdown-link">
            <el-badge class="item" is-dot/>
            快速信息
            <i class="el-icon-caret-bottom el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>未处理反馈
              <el-badge is-dot/>
            </el-dropdown-item>
            <el-dropdown-item>未处理审核
              <el-badge is-dot/>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div class="exit">
        <el-tooltip placement="bottom"
                    :offset="-10"
                    :enterable="false"
                    content="退出登录">
          <el-button type="text" @click="exit"><i class="ion-android-exit"></i></el-button>
        </el-tooltip>
      </div>
    </header>
    <div class="menu">
      <!--菜单伸展按钮-->
      <div class="collapse-button">
        <el-button type="text" @click="collapse = !collapse">
          <span v-if="collapse">&nbsp;展开<i style="min-width: 20px;margin-right: -5px;"
                                           class="el-icon-d-arrow-right"></i></span>
          <span v-else><i style="min-width: 20px" class="el-icon-d-arrow-left"></i>收起</span>
        </el-button>

      </div>
      <!--菜单-->
      <el-menu theme="dark" class="el-menu-vertical" unique-opened :collapse="collapse"
               @select="jumpTo">
        <el-submenu v-for="(menu, index) in menus" :index="index" :key="index">
          <template slot="title">
            <i :class="menu.icon"></i>
            <span slot="title" class="menu-name">{{menu.name}}</span>
          </template>
          <el-menu-item v-for="submenu in allSubmenus[index]" :key="index+ '-' + submenu.index"
                        :index="index+ '/' + submenu.index">
            {{submenu.name}}
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </div>
    <!--右部主要内容-->
    <div class="main-content">
      <div class="body">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import app from '../store/app';
  import {DO_LOGOUT} from '../store/types';

  export default {
    name: 'index',
    props: {
      // 参数
    },
    components: {
      // 组件
    },
    data () {
      // 数据
      return {
        app: app,
        collapse: false,
        menus: {
          'bikes': {icon: 'ion-android-bicycle', name: '车辆管理'},
          'users': {icon: 'ion-android-contacts', name: '用户管理'},
          'feedback': {icon: 'ion-ios-information-outline', name: '反馈管理'},
          'activities': {icon: 'ion-ios-infinite', name: '活动管理'},
          'privileges': {icon: 'ion-ios-locked', name: '权限管理'},
          'me': {icon: 'ion-android-person', name: '个人中心'}
        },
        allSubmenus: {
          'bikes': [
            {index: 'all', name: '全部车辆'},
            {index: 'add', name: '增加车辆'}
          ],
          'users': [
            {index: 'all', name: '全部用户'},
            {index: 'add', name: '添加用户'}
          ],
          'feedback': [
            {index: 'all', name: '全部反馈'},
            {index: 'statistics', name: '反馈统计'}
          ],
          'activities': [
            {index: 'all', name: '全部活动'},
            {index: 'statistics', name: '活动统计'}
          ],
          'privileges': [
            {index: 'all', name: '权限一览'},
            {index: 'modify', name: '修改权限'}
          ],
          'me': [
            {index: 'info', name: '我的信息'},
            {index: 'resetpwd', name: '修改密码'}
          ]
        }
      };
    },
    beforeRouteEnter (to, from, next) {
      next();
    },
    methods: {
      // 方法
      exit () {
        this.$store.dispatch(DO_LOGOUT);
        this.$router.push('/');
      },
      jumpTo (index, path) {
        this.$router.push('/' + index);
      }
    },
    computed: {
      adminId () {
        return this.$store.getters.adminInfo.adminId;
      }
    }
  }
  ;
</script>
<style scoped>
  .index {
    width: 100%;
    height: 100%;
  }

  .header {
    position: relative;
    top: 0;
    left: 0;
    width: 100%;
    height: 70px;
    color: #F9FAFC;
    background-color: #324057;
  }

  .header div {
    height: 70px;
    line-height: 70px;
  }

  .header .brand {
    float: left;
  }

  .header .brand .name {
    margin-left: 20px;
    display: inline-block;
    width: 210px;
    font-size: 1.8em;
  }

  .header .brand .version {
    display: inline-block;
    margin-left: 10px;
    width: 80px;
  }

  .header .exit {
    text-align: center;
    height: 70px;
    width: 70px;
    float: right;
  }

  .header .exit button {
    height: 100%;
  }

  .header .exit i {
    font-size: 32px;
    color: #F9FAFC;
  }

  .header .greeting {
    position: absolute;
    right: 200px;
    display: inline-block;
  }

  .header .quick-message {
    position: absolute;
    height: 70px;
    right: 70px;
    display: inline-block;
  }

  .header .quick-message span {
    cursor: pointer;
    font-size: 16px;
    color: #fff;
  }

  .header .user {
    color: #EFF2F7;
    text-decoration: none;
  }

  .menu {
    position: fixed;
    top: 20%;
    z-index: 9999;
  }

  .collapse-button {
    width: 64px;
    text-align: center;
    position: relative;
    top: 15%;
    z-index: 9999;
  }

  .collapse-button .el-button--text {
    color: #212121;
  }

  .el-menu-vertical, .el-menu--collapse {
    position: relative;
    top: 20%;
  }

  .el-menu-vertical:not(.el-menu--collapse) li {
    min-width: 150px;
  }

  .el-menu-vertical .el-submenu i {
    position: relative;
    top: 3px;
    width: 2em;
    font-size: 1.8em;
  }

  .menu-name {
    float: right;
    margin-right: 20px;
  }

  .main-content {
    position: relative;
    top: 10px;
    left: 160px;
    width: 85%;
    min-height: 500px;
  }

  .main-content .body {
    min-height: inherit;
    width: 100%;
  }
</style>

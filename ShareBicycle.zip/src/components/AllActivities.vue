<template>
  <div class="container">
    <el-row :gutter="10" style="margin-bottom: 10px">
      <el-col :span="3">
        <el-select v-model="option" placeholder="请选择">
          <el-option
            v-for="option in options"
            :key="option.value"
            :label="'按 ' + option.label"
            :value="option.value">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="8">
        <el-input placeholder="搜索">
          <el-button slot="append" icon="search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="13" style="text-align: right">
        <el-button type="primary" :loading="loading" @click="reload">{{loading? '加载中':'刷新'}}</el-button>
      </el-col>
    </el-row>
    <el-tabs @tab-click="handleClick">
      <el-tab-pane name="all">
        <span slot="label"><i class="el-icon-date"></i> 所有活动</span>
      </el-tab-pane>
      <el-tab-pane name="unreviewed">
        <span slot="label"><i class="el-icon-message"></i> 未审核 <el-badge class="item" is-dot/></span>
      </el-tab-pane>
    </el-tabs>
    <el-table
      :data="activities"
      v-loading.body="loading"
      border
      stripe
      max-height="500"
      style="width: 100%">
      <el-table-column type="expand" width="30">
        <template scope="props">
          <div class="content">
            <div class="description">{{ props.row.description }}</div>
            <span class="createTime">{{ props.row.createTime }}</span>
            <div v-if="props.row.status == 0" class="unhandled">
              <el-button type="success" size="small" @click="submit(props.row, 1)">准许</el-button>
              <el-button type="danger" size="small" @click="submit(props.row, -1)">回绝</el-button>
            </div>
            <div v-else-if="props.row.status == 1" class="handled check">
              <i class="ion-checkmark"></i>
            </div>
            <div v-else-if="props.row.status == -1" class="handled uncheck">
              <i class="ion-close"></i>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="id"
        label="编号"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="userId"
        label="提出人"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="title"
        label="标题"
        align="center">
      </el-table-column>
      <el-table-column
        prop="createTime"
        label="创建时间"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="startTime"
        label="开始时间"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="endTime"
        label="结束时间"
        align="center"
        width="180">
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        align="center"
        width="80">
      </el-table-column>
    </el-table>
    <el-row style="margin-top: 10px">
      <el-col :span="6">&nbsp;</el-col>
      <el-col :span="12" style="text-align: center">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pagination.currentPage"
          :page-sizes="pagination.pageSizes"
          :page-size="pagination.pageSize"
          layout="sizes, prev, pager, next, jumper"
          :total="pagination.total">
        </el-pagination>
      </el-col>
      <el-col :span="6">&nbsp;</el-col>
    </el-row>
  </div>
</template>
<script type="text/ecmascript-6">
  import {mapGetters} from 'vuex';
  //  import qs from 'qs';

  export default {
    name: 'all-activities',
    data () {
      // 数据
      return {
        loading: false,
        option: 1,
        options: [
          {
            label: '编号',
            value: 1
          }
        ],
        activities: [
          {
            id: '1',
            userId: '1',
            title: 'Activity-1',
            createTime: new Date().toLocaleDateString(),
            startTime: new Date().toLocaleDateString(),
            endTime: new Date().toLocaleDateString(),
            description: '这个活动旨在提倡大家多出去走走',
            status: 0
          }
        ]
      };
    },
    methods: {
      /**
       * 准许（1）或回绝（-1）
       * @param row 所在行
       * @param status
       */
      submit (row, status) {
        // 需要加回绝理由
        // TODO
        if (status === -1) {
          this.$prompt('请输入回绝理由', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消'
          }).then(({value}) => {
            let len = 10;
            let msg = value.length > len ? value.substring(0, len) + '...' : value;
            this.$message({
              type: 'success',
              message: '回绝成功，理由：' + msg
            });
            row.status = status;
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消'
            });
          });
        } else {
          this.$axios.put('/testJson', {username: 'hello'}, {headers: {'Content-type': 'application/json, charset=UTF-8'}})
            .then((resp) => {
              row.status = status;
              this.$message({
                type: 'success',
                message: '成功'
              });
            })
            .catch((err) => {
              this.$message({
                type: 'error',
                message: '失败' + err
              });
            });
        }
      },
      // 刷新按钮
      reload () {
        if (!this.loading) {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
            this.$message.success('更新成功');
          }, 3000);
        }
      },
      // 处理分页
      handleSizeChange (val) {
        // TODO
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange (val) {
        // TODO
        console.log(`当前页: ${val}`);
      },
      handleClick (tab, event) {
        console.log(tab.name);
      }
    },
    computed: {
      // 计算属性
      ...mapGetters({
        pagination: 'activitiesPagination'
      })
    }
  };
</script>
<style scoped>
  @import "../assets/global/css/global.css";

  .content {
    line-height: 2;
    width: 100%;
  }

  .content:before {
    content: '活动描述';
    display: block;
    color: #8c939d;
    width: 120px;
    min-height: 40px;
    font-size: 1.2em;
  }

  .createTime {
    display: inline-block;
    color: #8c939d;
    font-size: 12px;
    float: right;
    margin-right: 15px;
  }

  .item {
    position: absolute;
  }

  .handled {
    position: absolute;
    font-size: 2.6em;
    top: 20px;
    right: 80px;
  }

  .check {
    color: #13CE66;
  }

  .uncheck {
    color: #FF4949;
  }

  .unhandled {
    position: relative;
    top: 10px;
  }
</style>

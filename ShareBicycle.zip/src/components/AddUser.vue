<template>
  <div class="container">
    <div class="form-title"><span>添加新用户</span></div>
    <el-form label-position="right" ref="form" label-width="120px" :model="form">
      <el-form-item label="用户名" required prop="username">
        <el-input class="w-60" v-model="form.username" autofocus :maxlength="18" :minlength="8"></el-input>
      </el-form-item>
      <el-form-item label="密码" required prop="password">
        <el-input class="w-60" v-model="form.password" type="password" :maxlength="20" :minlength="8"></el-input>
      </el-form-item>
      <el-form-item label="确认密码" required prop="password">
        <el-input class="w-60" v-model="form.password2" type="password" :maxlength="20"></el-input>
      </el-form-item>
      <el-form-item label="姓名" required prop="name">
        <el-input class="w-60" v-model="form.name"></el-input>
      </el-form-item>
      <el-form-item>
        <el-checkbox v-model="form.needCard">办理骑行卡</el-checkbox>
      </el-form-item>
      <el-form-item v-if="form.needCard" label="卡号">
        <!--自动搜索完成-->
        <el-input class="w-60" v-model="form.cardNumber">
          <el-button slot="append" icon="search" :loading="form.checking"></el-button>
        </el-input>
      </el-form-item>
      <el-form-item v-if="form.needCard" label="账户金额">
        <el-input class="w-60" v-model="form.balance"></el-input>
      </el-form-item>
      <el-form-item label="电话" required prop="phone">
        <el-input class="w-60" v-model="form.phone"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" :loading="form.submitting">提&nbsp;交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    name: 'add-user',
    props: {
      // 参数
    },
    components: {
      // 组件
    },
    data () {
      // 数据
      return {
        form: {
          username: '',
          password: '',
          password2: '',
          name: '',
          cardNumber: '',
          phone: '',
          balance: '',
          needCard: true,
          checking: false,
          submitting: false
        }
      };
    },
    methods: {
      // 方法
    },
    computed: {
      // 计算属性
    },
    filters: {
      // 过滤器
    },
    watch: {
      // 监听器
    }
  };
</script>
<style scoped>
  @import "../assets/global/css/global.css";

  .el-form {
    width: 55%;
    margin-left: auto;
    margin-right: auto;
  }

  .form-title {
    width: 100%;
    height: 50px;
    line-height: 30px;
    font-size: 1.4em;
    text-align: center;
  }
</style>

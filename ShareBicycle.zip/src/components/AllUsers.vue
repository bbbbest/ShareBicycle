<template>
  <div class="container">
    <el-row :gutter="10" style="margin-bottom: 10px">
      <el-col :span="3">
        <el-select v-model="option" placeholder="请选择">
          <el-option
            v-for="option in options"
            :key="option.value"
            :label="'按 ' + option.label"
            :value="option.value">
          </el-option>
        </el-select>
      </el-col>
      <el-col :span="8">
        <el-input placeholder="搜索">
          <el-button slot="append" icon="search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="13" style="text-align: right">
        <span><router-link type="text" to="/users/add"
                           style="text-decoration: none;margin-right: 10px">添加新用户</router-link></span>
        <el-button type="primary" :loading="loading" @click="reload">{{loading? '加载中':'刷新'}}</el-button>
      </el-col>
    </el-row>
    <el-tabs>
      <el-tab-pane>
        <span slot="label"><i class="el-icon-date"></i> 所有用户</span>
      </el-tab-pane>
      <el-tab-pane label="未处理申请"></el-tab-pane>
    </el-tabs>
    <el-table
      :data="users"
      :loading="loading"
      border
      stripe
      @row-dblclick="showPersonChart"
      max-height="500">
      <el-table-column
        prop="userId"
        label="编号"
        align="center"
        width="120">
      </el-table-column>
      <el-table-column
        prop="username"
        label="用户名"
        align="center"
        width="120">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名"
        align="center"
        width="120">
      </el-table-column>
      <el-table-column
        prop="cardNumber"
        label="卡编号"
        align="center">
      </el-table-column>
      <el-table-column
        prop="score"
        label="积分"
        align="center"
        width="80">
      </el-table-column>
      <el-table-column
        prop="phone"
        label="电话"
        align="center">
      </el-table-column>
      <el-table-column
        prop="status"
        label="状态"
        align="center"
        width="80">
      </el-table-column>
      <el-table-column
        prop="balance"
        label="账户余额"
        align="center"
        width="120">
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        width="120">
        <template scope="scope">
          <el-button size="small" type="text" @click="edit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="del(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-row style="margin-top: 10px">
      <el-col :span="6">&nbsp;</el-col>
      <el-col :span="12" style="text-align: center">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pagination.currentPage"
          :page-sizes="pagination.pageSizes"
          :page-size="pagination.pageSize"
          layout="sizes, prev, pager, next, jumper"
          :total="pagination.total">
        </el-pagination>
      </el-col>
      <el-col :span="6">&nbsp;</el-col>
    </el-row>
    <el-dialog
      :modal-append-to-body="false"
      title="提示"
      :visible.sync="dialogVisible"
      size="large"
      :before-close="handleDialogClose">
      <!--编辑用户信息-->
      <!--查看用户报表-->
    </el-dialog>
  </div>
</template>
<script type="text/ecmascript-6">
  import {mapGetters} from 'vuex';
//  import * as types from '../store/types';

  export default {
    name: 'all-users',
    props: {
      // 参数
    },
    components: {
      // 组件
    },
    data () {
      // 数据
      return {
        loading: false,
        option: 1,
        options: [
          {
            label: '编号',
            value: 1
          },
          {
            label: '用户名',
            value: 2
          },
          {
            label: '姓名',
            value: 3
          },
          {
            label: '卡号',
            value: 4
          },
          {
            label: '电话',
            value: 5
          }
        ],
        dialogVisible: false,
        users: [
          {
            userId: '1',
            username: 'yangjie',
            name: '杨洁',
            cardNumber: '123456',
            score: '60',
            phone: '15525552552',
            status: '1',
            balance: '60'
          },
          {
            userId: '2',
            username: 'cuihao',
            name: '崔浩',
            cardNumber: '223456',
            score: '60',
            phone: '15525552553',
            status: '1',
            balance: '60'
          }
        ]
      };
    },
    methods: {
      // 方法
      reload () {
        if (!this.loading) {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
          }, 500);
        }
      },
      addUser () {
        this.$message({
          message: 'Add Success',
          type: 'success',
          duration: 1000
        });
      },
      showPersonChart (row, event) {
        this.$message({
          message: 'OK',
          type: 'success',
          duration: 1000
        });
      },
      openDialog () {
        this.dialogVisible = true;
      },
      closeDialog () {
        this.dialogVisible = false;
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`);
      },
      handleDialogClose () {
        this.closeDialog();
        this.$message({
          message: '取消操作',
          type: 'info',
          duration: 1000
        });
      },
      edit (row) {
        this.openDialog();
      },
      del (row) {
        this.$confirm('您即将删除一名可爱的用户, 仍要继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      }
    },
    computed: {
      // 计算属性
      ...mapGetters({
        pagination: 'usersPagination'
      })
    },
    filters: {
      // 过滤器
    },
    watch: {
      // 监听器
    }
  };
</script>
<style scoped>
  @import "../assets/global/css/global.css";
  .el-select .el-input {
    width: 110px;
  }
</style>

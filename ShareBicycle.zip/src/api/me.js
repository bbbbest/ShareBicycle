import axios from './axiosConfig/axiosProxy';
import qs from 'qs';

export default {
  check ({username, password}) {
    return axios.post('/admin', qs.stringify({
      username: username,
      password: password
    }));
  },
  resetPWD ({old, n}) {
    return axios.post('/pwd', qs.stringify({old: old, n: n}));
  }
};

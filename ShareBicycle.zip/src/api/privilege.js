import axios from './axiosConfig/axiosProxy';

export default {
  getAll () {
    return axios.get('/privileges');
  }
};

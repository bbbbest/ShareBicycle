import axios from 'axios';

axios.defaults.baseURL = 'http://localhost:8080';
axios.defaults.timeout = 1000;
axios.defaults.headers = {
  'Content-Type': 'application/json'
};
// 添加请求拦截器
axios.interceptors.request.use(function (config) {
  if (config.method !== 'get') {
    config.headers['Access-Control-Request-Headers'] = 'Access-Control-Allow-Credentials';
    config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
  }
  return config;
}, function (error) {
  return Promise.reject(error);
});

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  return response;
}, function (error) {
  return Promise.reject(error);
});

Ajax = {};
